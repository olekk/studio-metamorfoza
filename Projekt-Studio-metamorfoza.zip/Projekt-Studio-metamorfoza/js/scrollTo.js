jQuery(function ($) {
    //zresetuj scrolla
        
    $.scrollTo(0);

    $('#link0').click(function () {
        $.scrollTo($('#start'), 800);
    });
    $('#link1').click(function () {
        $.scrollTo($('#kosme'), 800);
    });
    $('#link2').click(function () {
        $.scrollTo($('#wiza'), 800);
    });
    $('#link3').click(function () {
        $.scrollTo($('#makij'), 800);
    });
    $('#link4').click(function () {
        $.scrollTo($('#cenn'), 800);
    });
    $('#link5').click(function () {
        $.scrollTo($('#mapp'), 800);
    });
    $('#link6').click(function () {
        $.scrollTo($('#konta'), 800);
    });
    $('#link7').click(function () {
        $.scrollTo($('#kosme'), 800);
    });
    
    
});
